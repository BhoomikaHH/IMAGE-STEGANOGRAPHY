# Image Stenography With Python

## Run In (cmd)

**_Python ImageStenography.py_**

- Make sure you have python installed.
- 👉 Check Latest Release for best experiences.

## About Project: 

- Stenography: In simple words it is, **Hiding text in an image.**

- Note: it can be seenable from a software.

## 🔒 Encoding:

![EncodingInImagePython](https://user-images.githubusercontent.com/48137657/184625162-5393be69-98e1-4da2-8b86-62eeb1d46b55.PNG)

## 📜 Decoding: 

![DecodingImage](https://user-images.githubusercontent.com/48137657/184625204-6dd68b16-c2df-45c5-b35a-f0df92609217.PNG)
